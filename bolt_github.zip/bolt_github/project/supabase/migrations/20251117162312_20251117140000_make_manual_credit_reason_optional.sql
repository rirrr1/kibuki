/*
  # Make Manual Credit Reason Optional

  ## Overview
  Updates the `manually_add_credits_admin` function to make the reason parameter optional.
  If no reason is provided, it will use a default message.

  ## Changes
  - Modify `manually_add_credits_admin` function to accept NULL or empty string for reason
  - Use default message when reason is not provided
*/

-- ============================================================================
-- Update Manual Credit Addition Function to Make Reason Optional
-- ============================================================================

CREATE OR REPLACE FUNCTION manually_add_credits_admin(
    p_user_email text,
    p_credits integer,
    p_reason text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
    v_user_id uuid;
    v_current_balance integer;
    v_credit_result jsonb;
    v_description text;
    v_actual_reason text;
BEGIN
    -- Check if user is admin
    IF NOT is_admin() THEN
        RAISE EXCEPTION 'Access denied. Admin only.';
    END IF;

    -- Validate inputs
    IF p_credits IS NULL OR p_credits <= 0 THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'Credits must be a positive number'
        );
    END IF;

    -- Use default reason if not provided
    IF p_reason IS NULL OR trim(p_reason) = '' THEN
        v_actual_reason := 'Manual credit addition by admin';
    ELSE
        v_actual_reason := p_reason;
    END IF;

    -- Find user by email
    SELECT id INTO v_user_id
    FROM auth.users
    WHERE email = p_user_email;

    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'User not found with email: ' || p_user_email
        );
    END IF;

    -- Get current balance before adding credits
    SELECT credit_balance INTO v_current_balance
    FROM user_credits
    WHERE user_id = v_user_id;

    IF v_current_balance IS NULL THEN
        v_current_balance := 0;
    END IF;

    -- Build description
    v_description := 'Manual credit addition by admin: ' || v_actual_reason;

    -- Add credits using the existing add_credits function
    SELECT * INTO v_credit_result
    FROM add_credits(
        p_user_id := v_user_id,
        p_amount := p_credits,
        p_transaction_type := 'adjustment',
        p_description := v_description,
        p_stripe_payment_intent_id := NULL
    );

    -- Return success with details
    RETURN jsonb_build_object(
        'success', true,
        'user_id', v_user_id,
        'user_email', p_user_email,
        'credits_added', p_credits,
        'previous_balance', v_current_balance,
        'new_balance', (v_credit_result->0->>'new_balance')::integer,
        'reason', v_actual_reason,
        'added_at', now()
    );
EXCEPTION
    WHEN OTHERS THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', SQLERRM,
            'error_detail', SQLSTATE
        );
END;
$$;